package com.example.daniilss18019262_cs6051_cw.models;

import java.util.Date;

public class ChatMessages {
    public String senderId, receiverId, message, dateTime;
    public Date dataObject;
    public String conversionId, conversionName, conversionImage;
}

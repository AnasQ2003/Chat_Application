package com.example.daniilss18019262_cs6051_cw.listeners;

import com.example.daniilss18019262_cs6051_cw.models.User;

public interface UserListener {
    void onUserClicked(User user);
}

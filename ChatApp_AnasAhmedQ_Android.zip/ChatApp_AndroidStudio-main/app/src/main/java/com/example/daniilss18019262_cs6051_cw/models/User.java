package com.example.daniilss18019262_cs6051_cw.models;

import java.io.Serializable;

public class User implements Serializable {
    public String name, image, email, token, id;
}
